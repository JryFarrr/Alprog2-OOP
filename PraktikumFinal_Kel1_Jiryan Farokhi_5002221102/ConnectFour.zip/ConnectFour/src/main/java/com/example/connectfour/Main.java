//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.example.connectfour;

import java.io.IOException;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Main extends Application {
    private Controller controller;

    public Main() {
    }

    // Metode start untuk memulai aplikasi
    public void start(Stage stage) throws IOException {
        // Memuat file FXML
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("game.fxml"));
        GridPane rootGridPane = (GridPane)fxmlLoader.load();
        // Mengambil controller dari FXML loader
        this.controller = (Controller)fxmlLoader.getController();
        // Membuat playground
        this.controller.createPlayground();
        // Membuat menu bar
        MenuBar menuBar = this.createMenu();
        menuBar.prefWidthProperty().bind(stage.widthProperty());
        // Menambahkan menu bar ke pane
        Pane menuPane = (Pane)rootGridPane.getChildren().get(0);
        menuPane.getChildren().add(menuBar);
        // Mengatur scene dan menampilkan stage
        Scene scene = new Scene(rootGridPane);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    // Metode untuk membuat menu bar
    private MenuBar createMenu() {
        // Membuat menu 'File'
        Menu fileMenu = new Menu("File");
        // Membuat item menu 'New Game'
        MenuItem newGame = new MenuItem("Game baru");
        newGame.setOnAction((actionEvent) -> {
            this.controller.resetGame();
        });
        // Membuat item menu 'Reset Game'
        MenuItem resetGame = new MenuItem("Ulang game");
        resetGame.setOnAction((actionEvent) -> {
            this.controller.resetGame();
        });
        // Separator menu item
        SeparatorMenuItem separatorMenuItem = new SeparatorMenuItem();
        // Membuat item menu 'Exit Game'
        MenuItem exitGame = new MenuItem("Keluar game");
        exitGame.setOnAction((actionEvent) -> {
            this.exitGame();
        });
        // Menambahkan semua item ke menu 'File'
        fileMenu.getItems().addAll(new MenuItem[]{newGame, resetGame, separatorMenuItem, exitGame});
        // Membuat menu 'Help'
        Menu helpMenu = new Menu("Bantuan");
        // Membuat item menu 'About Game'
        MenuItem aboutGame = new MenuItem("Tentang Game");
        aboutGame.setOnAction((actionEvent) -> {
            this.aboutGame();
        });
        SeparatorMenuItem separator = new SeparatorMenuItem();
        // Menambahkan semua item ke menu 'Help'
        helpMenu.getItems().addAll(new MenuItem[]{aboutGame, separator});
        // Membuat menu bar dan menambahkan menu 'File' dan 'Help'
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(new Menu[]{fileMenu, helpMenu});
        return menuBar;
    }

    // Metode untuk menampilkan informasi tentang permainan
    private void aboutGame() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Tentang Connect game");
        alert.setHeaderText("Gimana cara main? ");
        alert.setContentText("Connect Four is a two-player connection game in which the\n players first choose a color and then take turns dropping colored discs\n from the top into a seven-column, six-row vertically suspended grid.\n The pieces fall straight down, occupying the next available space within\n the column. The objective of the game is to be the first to form a horizontal,\n vertical, or diagonal line of four of one's own discs. Connect Four is a\n solved game. The first player can always win by playing the right moves.");
        alert.show();
    }

    // Metode untuk keluar dari permainan
    private void exitGame() {
        Platform.exit();
        System.exit(0);
    }

    // Metode reset game, saat ini tidak melakukan apa-apa
    private void resetGame() {
    }

    // Metode main untuk meluncurkan aplikasi
    public static void main(String[] args) {
        launch(new String[0]);
    }
}
