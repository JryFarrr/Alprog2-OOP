//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.example.connectfour;

        import java.net.URL;
        import java.util.ArrayList;
        import java.util.Iterator;
        import java.util.List;
        import java.util.Optional;
        import java.util.ResourceBundle;
        import java.util.stream.Collectors;
        import java.util.stream.IntStream;
        import javafx.animation.TranslateTransition;
        import javafx.application.Platform;
        import javafx.fxml.FXML;
        import javafx.fxml.Initializable;
        import javafx.geometry.Point2D;
        import javafx.scene.control.Alert;
        import javafx.scene.control.Button;
        import javafx.scene.control.ButtonType;
        import javafx.scene.control.Label;
        import javafx.scene.control.TextField;
        import javafx.scene.control.Alert.AlertType;
        import javafx.scene.layout.GridPane;
        import javafx.scene.layout.Pane;
        import javafx.scene.paint.Color;
        import javafx.scene.shape.Circle;
        import javafx.scene.shape.Rectangle;
        import javafx.scene.shape.Shape;
        import javafx.util.Duration;

public class Controller implements Initializable {
    // Konstanta untuk jumlah kolom dan baris serta diameter lingkaran
    private static final int COLUMNS = 7;
    private static final int ROWS = 6;
    private static final int CIRCLE_DIAMETER = 80;
    private static final String discColor1 = "#24303E";
    private static final String discColor2 = "#4CAA88";
    private static String PLAYER_ONE = "Player One";
    private static String PLAYER_TWO = "Player Two";
    // Variabel untuk melacak giliran pemain
    private boolean isPlayerOneTurn = true;
    // Array 2D untuk menyimpan disc yang dimasukkan
    private Disc[][] insertedDiscArray = new Disc[6][7];
    @FXML
    public GridPane rootGridPane; // GridPane utama
    @FXML
    public Pane insertedDiscsPane; // Pane untuk disc yang dimasukkan
    @FXML
    public Label playerNameLabel; // Label untuk menampilkan nama pemain
    @FXML
    public TextField playerOneTextField; // TextField untuk nama pemain satu
    @FXML
    public TextField playerTwoTextField;  // TextField untuk nama pemain dua
    @FXML
    public Button setNamesButton;  // TextField untuk nama pemain dua
    // Flag untuk mengizinkan pemasukan disc
    private boolean isAllowToInsert = true;

    public Controller() {
    }

    // Metode untuk membuat arena permainan
    public void createPlayground() {
        // Mengatur aksi untuk tombol set names
        this.setNamesButton.setOnAction((event) -> {
            PLAYER_ONE = this.playerOneTextField.getText();
            PLAYER_TWO = this.playerTwoTextField.getText();
        });
        // Membuat grid struktur permainan
        Shape rectangleWithHoles = this.createGameStructuralGrid();
        this.rootGridPane.add(rectangleWithHoles, 0, 1);
        // Membuat daftar kolom yang dapat diklik
        List<Rectangle> rectangleList = this.createClickableColumns();
        Iterator var3 = rectangleList.iterator();

        while(var3.hasNext()) {
            Rectangle rectangle = (Rectangle)var3.next();
            this.rootGridPane.add(rectangle, 0, 1);
        }

    }

    // Metode untuk membuat grid struktur permainan dengan lubang
    private Shape createGameStructuralGrid() {
        Shape rectangleWithHoles = new Rectangle(640.0, 560.0);

        // Membuat lubang dalam grid untuk disc
        for(int row = 0; row < 6; ++row) {
            for(int col = 0; col < 7; ++col) {
                Circle circle = new Circle();
                circle.setRadius(40.0);
                circle.setCenterX(40.0);
                circle.setCenterY(40.0);
                circle.setSmooth(true);
                circle.setTranslateX((double)(col * 85 + 20));
                circle.setTranslateY((double)(row * 85 + 20));
                rectangleWithHoles = Shape.subtract((Shape)rectangleWithHoles, circle);
            }
        }

        ((Shape)rectangleWithHoles).setFill(Color.WHITE);
        return (Shape)rectangleWithHoles;
    }

    // Metode untuk membuat kolom yang dapat diklik
    private List<Rectangle> createClickableColumns() {
        List<Rectangle> rectangleList = new ArrayList();

        for(int col = 0; col < 7; ++col) {
            Rectangle rectangle = new Rectangle(80.0, 560.0);
            rectangle.setFill(Color.TRANSPARENT);
            rectangle.setTranslateX((double)(col * 85 + 20));
            rectangle.setOnMouseEntered((event) -> {
                rectangle.setFill(Color.valueOf("#eeeeee26"));
            });
            rectangle.setOnMouseExited((event) -> {
                rectangle.setFill(Color.TRANSPARENT);
            });
            // Menambahkan aksi saat kolom diklik
            int finalCol = col;
            rectangle.setOnMouseClicked((event) -> {
                if (this.isAllowToInsert) {
                    this.isAllowToInsert = false;
                    this.insertDisc(new Disc(this.isPlayerOneTurn), finalCol);
                }

            });
            rectangleList.add(rectangle);
        }

        return rectangleList;
    }

    // Metode untuk memasukkan disc ke dalam kolom yang dipilih
    private void insertDisc(Disc disc, int column) {
        int row;
        for(row = 5; row >= 0 && this.getDiscIfPresent(row, column) != null; --row) {
        }

        if (row >= 0) {
            this.insertedDiscArray[row][column] = disc;
            this.insertedDiscsPane.getChildren().add(disc);
            disc.setTranslateX((double)(column * 85 + 20));
            TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(0.5), disc);
            translateTransition.setToY((double)(row * 85 + 20));
            int finalRow = row;
            // Animasi transisi untuk disc yang jatuh
            translateTransition.setOnFinished((actionEvent) -> {
                this.isAllowToInsert = true;
                if (this.gameEnded(finalRow, column)) {
                    this.gameOver();
                } else {
                    this.isPlayerOneTurn = !this.isPlayerOneTurn;
                    this.playerNameLabel.setText(this.isPlayerOneTurn ? PLAYER_ONE : PLAYER_TWO);
                }
            });
            translateTransition.play();
        }
    }

    // Metode untuk memeriksa apakah permainan berakhir
    private boolean gameEnded(int row, int column) {
        // Memeriksa kombinasi vertikal, horizontal, dan diagonal untuk menemukan 4 disc berturut-turut
        List<Point2D> verticalPoints = (List)IntStream.rangeClosed(row - 3, row + 3).mapToObj((r) -> {
            return new Point2D((double)r, (double)column);
        }).collect(Collectors.toList());
        List<Point2D> horizontalPoints = (List)IntStream.rangeClosed(column - 3, column + 3).mapToObj((col) -> {
            return new Point2D((double)row, (double)col);
        }).collect(Collectors.toList());
        Point2D startPoint1 = new Point2D((double)(row - 3), (double)(column + 3));
        List<Point2D> diagonalPoints = (List)IntStream.rangeClosed(0, 6).mapToObj((i) -> {
            return startPoint1.add((double)i, (double)(-i));
        }).collect(Collectors.toList());
        Point2D startPoint2 = new Point2D((double)(row - 3), (double)(column - 3));
        List<Point2D> diagonal2Points = (List)IntStream.rangeClosed(0, 6).mapToObj((i) -> {
            return startPoint2.add((double)i, (double)i);
        }).collect(Collectors.toList());
        // Memeriksa kombinasi untuk menentukan apakah ada 4 disc berturut-turut
        boolean isEnded = this.checkCombinations(verticalPoints) || this.checkCombinations(horizontalPoints) || this.checkCombinations(diagonalPoints) || this.checkCombinations(diagonal2Points);
        return isEnded;
    }

    // Metode untuk memeriksa kombinasi disc
    private boolean checkCombinations(List<Point2D> points) {
        int chain = 0;
        Iterator var3 = points.iterator();

        label22:
        do {
            while(var3.hasNext()) {
                Point2D point = (Point2D)var3.next();
                int rowIndexForArray = (int)point.getX();
                int columnIndexForArray = (int)point.getY();
                Disc disc = this.getDiscIfPresent(rowIndexForArray, columnIndexForArray);
                if (disc != null && disc.isPlayerOneMove == this.isPlayerOneTurn) {
                    ++chain;
                    continue label22;
                }

                chain = 0;
            }

            return false;
        } while(chain != 4);

        return true;
    }

    // Metode untuk mendapatkan disc jika ada
    private Disc getDiscIfPresent(int row, int column) {
        return row < 6 && row >= 0 && column < 7 && column >= 0 ? this.insertedDiscArray[row][column] : null;
    }

    // Metode untuk menampilkan pesan akhir permainan
    private void gameOver() {
        String winner = this.isPlayerOneTurn ? PLAYER_ONE : PLAYER_TWO;
        System.out.println("Pemanangnya : " + winner);
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Connect four");
        alert.setHeaderText("Pemenangnya : " + winner);
        alert.setContentText("Mau main lagi ? ");
        // Tombol untuk opsi di akhir permainan
        ButtonType yesBtn = new ButtonType("Gasssss");
        ButtonType noBtn = new ButtonType("Udahann ah");
        // Menambahkan tombol opsi ke alert
        alert.getButtonTypes().setAll(new ButtonType[]{yesBtn, noBtn});
        // Menampilkan alert dan menunggu respon pengguna
        Platform.runLater(() -> {
            Optional<ButtonType> BtnClicked = alert.showAndWait();
            if (BtnClicked.isPresent() && BtnClicked.get() == yesBtn) {
                this.resetGame(); // Mengulang permainan jika pengguna memilih "Gasssss"
            } else {
                Platform.exit(); // Keluar dari aplikasi jika pengguna memilih "Udahann ah"
                System.exit(0);
            }

        });
    }

    // Method untuk mereset permainan
    public void resetGame() {
        // Menghapus semua disc yang dimasukkan dari pane
        this.insertedDiscsPane.getChildren().clear();

        // Mengosongkan array yang melacak disc yang dimasukkan
        for(int row = 0; row < this.insertedDiscArray.length; ++row) {
            for(int col = 0; col < this.insertedDiscArray[row].length; ++col) {
                this.insertedDiscArray[row][col] = null;
            }
        }

        // Mengatur giliran ke pemain satu dan memperbarui label nama pemain
        this.isPlayerOneTurn = true;
        this.playerNameLabel.setText(PLAYER_ONE);
        // Membuat ulang playground
        this.createPlayground();
    }

    // Metode untuk menginisialisasi controller
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }

    // Kelas private untuk merepresentasikan disc
    private static class Disc extends Circle {
        private final boolean isPlayerOneMove;

        public Disc(boolean isPlayerOneMove) {
            this.isPlayerOneMove = isPlayerOneMove;
            this.setRadius(40.0); // Mengatur radius disc
            this.setFill(isPlayerOneMove ? Color.valueOf("#24303E") : Color.valueOf("#4CAA88"));
            this.setCenterX(40.0);
            this.setCenterY(40.0);
        }
    }
}
